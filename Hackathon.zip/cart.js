
document.addEventListener("DOMContentLoaded", function(event) {


const cartButtons = document.querySelectorAll('.cart-button');

cartButtons.forEach(button => {

button.addEventListener('click',cartClick);

});

function cartClick(){
let button =this;
button.classList.add('clicked');
}

});

var cart = {
  // (A) PROPERTIES
  hPdt : null, // HTML products list
  hItems : null, // HTML current cart
  items : {}, // Current items in cart
  iURL : "images/", // Product image URL folder

  // (B) LOCALSTORAGE CART
  // (B1) SAVE CURRENT CART INTO LOCALSTORAGE
  save : () => {
    localStorage.setItem("cart", JSON.stringify(cart.items));
  },

  // (B2) LOAD CART FROM LOCALSTORAGE
  load : () => {
    cart.items = localStorage.getItem("cart");
    if (cart.items == null) { cart.items = {}; }
    else { cart.items = JSON.parse(cart.items); }
  },

  // (B3) EMPTY ENTIRE CART
  nuke : () => {
    if (confirm("Empty cart?")) {
      cart.items = {};
      localStorage.removeItem("cart");
      cart.list();
    }
  },

  // (C) INITIALIZE
  init : () => {
    // (C1) GET HTML ELEMENTS
    cart.hPdt = document.getElementById("cart-products");
    cart.hItems = document.getElementById("cart-items");
	console.log(products);
    // (C2) DRAW PRODUCTS LIST
    cart.hPdt.innerHTML = "";
    let p, item, part;
    for (let id in products) {
      // WRAPPER
	  if( id.includes("v")){
		  p = products[id];
		  item = document.createElement("div");
		  item.className = "column";
		  cart.hPdt.appendChild(item);
			
		  part1 = document.createElement("div");
		  part1.className = "flip-card";
		  item.appendChild(part1);	
		  
		  part2 = document.createElement("div");
		  part2.className = "flip-card-inner";
		  part1.appendChild(part2);
		  
		  part3 = document.createElement("div");
		  part3.className = "flip-card-front";
		  part2.appendChild(part3);

		  // PRODUCT IMAGE
		  partz = document.createElement("img");
		  partz.src = p.img1;
		  partz.style.width = "300px";
		  partz.style.height = "300px";
		  part3.appendChild(partz);

		  // PRODUCT NAME
		  part4 = document.createElement("div");
		  part4.className = "flip-card-back";
		  part4.style.backgroundColor = '#f2848280';
		  part4.style.color = '#4e0100';
		  part4.style.height = '280%'
		  part2.appendChild(part4);
		  
		  // PRODUCT DESCRIPTION
		  part5 = document.createElement("h1");
		  part5.innerHTML = p.name;
		  part4.appendChild(part5);


		 br = document.createElement("br");
		 part4.appendChild(br);
		 
		 part6 = document.createElement("p");
		  part6.innerHTML = p.desc;
		  part4.appendChild(part6);
		  part4.appendChild(br);
		  part4.appendChild(br);
		  
		  
		  part7 = document.createElement("p");
		  part4.appendChild(part7);
		  
		  part8 = document.createElement("img");
		  part8.src = p.img2;
		  part8.style.width = "300px";
		  part8.style.height = "300px";
		  part7.appendChild(part8);
		  
		  part4.appendChild(br);
		  
		  
		  part9 = document.createElement("p");
		  part4.appendChild(part9);
		  
		  part10 = document.createElement("img");
		  part10.src = p.img3;
		  part10.style.width = "300px";
		  part10.style.height = "300px";
		  part9.appendChild(part10);
		  part4.appendChild(br);
		  
		  part11 = document.createElement("p");
		  part11.innerHTML = "Price - Rs " + p.price;
		  part4.appendChild(part11);
		  part4.appendChild(br);
		 

			partb = document.createElement("p");
			part4.appendChild(partb);
			
			partc = document.createElement("div");
			partc.className = "buttons";
			part4.appendChild(partc);
			
			partd = document.createElement("button"); 
			partd.className = "cart-button";
			partd.onclick = () => { cart.add(id); };
			partc.appendChild(partd);
			
			parte = document.createElement("span"); 
			parte.innerHTML = "Add to cart";
			parte.className = "add-to-cart";
			partd.appendChild(parte);
			
			partf = document.createElement("span"); 
			partf.innerHTML = "Item added";
			partf.className = "added";
			partd.appendChild(partf);
			
			partg = document.createElement("i"); 
			partg.className = "fa fa-shopping-cart";
			partd.appendChild(partg);
			
			
			parth = document.createElement("i"); 
			parth.className = "fa fa-square";
			partd.appendChild(parth);
			
			parti = document.createElement("p");
			part4.appendChild(partb);
		  // ADD TO CART
		  //parta = document.createElement("input");
		  //parta.type = "button";
		  //parta.value = "Add to Cart";
		  //parta.className = "cart p-add";
		  //parta.onclick = () => { cart.add(id); };
		  //part4.appendChild(parta);
		}
	}
    // (C3) LOAD CART FROM PREVIOUS SESSION
    cart.load();

    // (C4) LIST CURRENT CART ITEMS
    cart.list();
  },

  // (D) LIST CURRENT CART ITEMS (IN HTML)
  list : () => {
    // (D1) RESET
    cart.hItems.innerHTML = "";
    let item, part, pdt;
    let empty = true;
    for (let key in cart.items) {
      if(cart.items.hasOwnProperty(key)) { empty = false; break; }
    }

    // (D2) CART IS EMPTY
    if (empty) {
      item = document.createElement("li");
      item.innerHTML = "Cart is empty";
      cart.hItems.appendChild(item);
    }

    // (D3) CART IS NOT EMPTY - LIST ITEMS
    else {
      let p, total = 0, subtotal = 0;
      for (let id in cart.items) {
        // ITEM
        p = products[id];
        item = document.createElement("div");
        item.className = "c-item";
        cart.hItems.appendChild(item);

        // NAME
        part = document.createElement("div");
        part.innerHTML = p.name;
        part.className = "c-name";
        item.appendChild(part);

        // REMOVE
        part = document.createElement("input");
        part.type = "button";
        part.value = "X";
        part.className = "c-del cart";
        part.onclick = () => { cart.remove(id); };
        item.appendChild(part);

        // QUANTITY
        part = document.createElement("input");
        part.type = "number";
        part.min = 0;
        part.value = cart.items[id];
        part.className = "c-qty";
        part.onchange = function () { cart.change(id, this.value); };
        item.appendChild(part);

        // SUBTOTAL
        subtotal = cart.items[id] * p.price;
        total += subtotal;
      }

      // TOTAL AMOUNT
      item = document.createElement("div");
      item.className = "c-total";
      item.id = "c-total";
      item.innerHTML ="TOTAL: Rs" + total;
      cart.hItems.appendChild(item);

      // EMPTY BUTTONS
      item = document.createElement("input");
      item.type = "button";
      item.value = "Empty";
      item.onclick = cart.nuke;
      item.className = "c-empty cart";
      cart.hItems.appendChild(item);

      // CHECKOUT BUTTONS
      item = document.createElement("input");
      item.type = "button";
      item.value = "Checkout";
      item.onclick = cart.checkout;
      item.className = "c-checkout cart";
      cart.hItems.appendChild(item);
    }
  },

  // (E) ADD ITEM INTO CART
  add : (id) => {
    if (cart.items[id] == undefined) { cart.items[id] = 1; }
    else { cart.items[id]++; }
    cart.save(); cart.list();
  },

  // (F) CHANGE QUANTITY
  change : (pid, qty) => {
    // (F1) REMOVE ITEM
    if (qty <= 0) {
      delete cart.items[pid];
      cart.save(); cart.list();
    }

    // (F2) UPDATE TOTAL ONLY
    else {
      cart.items[pid] = qty;
      var total = 0;
      for (let id in cart.items) {
        total += cart.items[id] * products[id].price;
        document.getElementById("c-total").innerHTML ="TOTAL: Rs" + total;
      }
    }
  },

  // (G) REMOVE ITEM FROM CART
  remove : (id) => {
    delete cart.items[id];
    cart.save();
    cart.list();
  },

  // (H) CHECKOUT
  checkout : () => {
	 let body1 = "";
	for (let id in cart.items) {
			// ITEM
			p = products[id];
			
			body1 += p.name + " - Rs ";
			body1 += "\n";
			body1 += p.price + ", ";
			body1 += "\n";
			
	}
	body1 += document.getElementById("c-total").innerHTML;
	
	this.sendEmail(body1);
	  // SEND DATA TO SERVER
    // CHECKS
    // SEND AN EMAIL
    // RECORD TO DATABASE
    // PAYMENT
    // WHATEVER IS REQUIRED
    /*
    var data = new FormData();
    data.append("cart", JSON.stringify(cart.items));
    data.append("products", JSON.stringify(products));

    fetch("SERVER-SCRIPT", { method:"POST", body:data })
    .then(res=>res.text()).then((res) => {
      console.log(res);
    })
    .catch((err) => { console.error(err); });
    */
  }
};
window.addEventListener("DOMContentLoaded", cart.init);

function sendEmail(body1) {
	console.log(body1);
      Email.send({
        Host: "smtp.gmail.com",
        Username: "trialerror12345678@gmail.com",
        Password: "papudirrtw",
        To: 'deveshtakoor@gmail.com' ,
        From: "trialerror12345678@gmail.com",
        Subject: "Your order",
        Body: body1	,
      })
        .then(function (message) {
          alert("Mail sent successfully")
        });
    }