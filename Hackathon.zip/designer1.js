var products = {
  1239: {
    name : "",
    desc : "",
    img1 : "",
    img2 : "",
    img3 : "",
    price : 
  },
  1240: {
    name : "",
    desc : "",
    img1 : "",
    img2 : "",
    img3 : "",
    price : 
  },
  1241: {
    name : "",
    desc : "",
    img1 : "",
    img2 : "",
    img3 : "",
    price : 
  },
  1242: {
    name : "",
    desc : "",
    img1 : "",
    img2 : "",
    img3 : "",
    price : 
  }
};