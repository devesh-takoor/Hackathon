Please Open file hackathon.html
And for the meantime only the venue site is able to send the mail