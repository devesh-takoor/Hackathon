// DUMMY PRODUCTS (PRODUCT ID : DATA)
var products = {
	
	//Venue
	  "v123": {
		name : "Wedding Hall",
		desc : "Our best wedding hall",
		img1 : "https://mir-s3-cdn-cf.behance.net/project_modules/1400_opt_1/c2bd6f44204847.580ada7ec5b0b.jpg",
		img2 : "https://mir-s3-cdn-cf.behance.net/project_modules/1400_opt_1/6b9aa444204847.580ada7ec5fea.jpg",
		img3 : "https://mir-s3-cdn-cf.behance.net/project_modules/1400_opt_1/5a155e44204847.580ada7ec64b0.jpg",
		price : 300000
	  },
	  "v124": {
		name : "Wedding Tent",
		desc : "Various wedding tents theme available with different size.",
		img1 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t39.30808-6/178114851_3999888613453245_6666544801599072359_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=boIK3_NmGt4AX_IXUPb&_nc_ht=scontent.fmru7-1.fna&oh=48f75f8a501147cd20ad3971fc36b2a0&oe=61B7D26C",
		img2 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t39.30808-6/200934805_3999890196786420_8422629890077541538_n.jpg?_nc_cat=107&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=DZ8mXxyKlVcAX8RzMaR&_nc_ht=scontent.fmru7-1.fna&oh=d6023899c786f9c858da2f162611858d&oe=61B6B8DD",
		img3 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/176930437_3755717054537070_5270902849258400576_n.jpg?_nc_cat=102&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=PmLpRZ4CGGAAX9BLlWb&_nc_ht=scontent.fmru7-1.fna&oh=e54d7d906d68843b32b1fca764cad254&oe=61D88E92",
		price : 100000
	  },
	  "v125": {
		name : "Wedding Marquee",
		desc : "Customise your marquee according to your own choices with different themes available.",
		img1 : "https://www.tentsandmarquees.com/wp-content/uploads/2019/03/Wedding-Hire-server2-copy.jpg",
		img2 : "https://www.tentsandmarquees.com/wp-content/uploads/2019/01/Wedding-Hire-server3.jpg",
		img3 : "https://www.tentsandmarquees.com/wp-content/uploads/2019/01/Wedding-Hire-server4.jpg",
		price : 300000
	  },
	  "v126": {
		name : "Open Air Wedding",
		desc : "Feel the cool breeze near the beautiful sea view.",
		img1 : "https://tidetheknotbeachweddings.com/wp-content/uploads/2019/10/Andrea-Marsden-2-1024x683.jpg",
		img2 : "https://tidetheknotbeachweddings.com/wp-content/uploads/2019/02/Tide-the-knot-blue-15-1024x683.jpg",
		img3 : "https://tidetheknotbeachweddings.com/wp-content/uploads/2019/10/Andrea-Marsden-16-1024x683.jpg",
		price : 150000
		},
	//Food
		"f127": {
		name : "7 curry (with ti puri)",
		desc : "Delicious colourful curries with plenty of flavours and served with small puris",
		img1 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/51993453_2196501043748765_4302364243295993856_n.jpg?_nc_cat=107&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=ZTNf9SNXfxkAX8K_t4t&tn=3u-jR1bXj4OXCdCr&_nc_ht=scontent.fmru7-1.fna&oh=4397df9def2cf2fef324777ab951d9bd&oe=61D8D226",
		img2 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/51438020_2196501003748769_3308637011480412160_n.jpg?_nc_cat=102&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=uRa7ElgjZsUAX-zylZa&tn=3u-jR1bXj4OXCdCr&_nc_ht=scontent.fmru7-1.fna&oh=d6fcf87d4d2cd8ad90c36fd51a17646c&oe=61D86837",
		
		price : 75
	  },
	  "f128": {
		name : "7 curry (with rasson)",
		desc : "Extra hot and spicy curries accompanied by a spicy drink (rasson).",
		img1 : "https://i.ytimg.com/vi/sd_02ajSqT0/maxresdefault.jpg",
		img2 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/45425598_1511736805637617_1947713049636896768_n.jpg?_nc_cat=111&ccb=1-5&_nc_sid=e3f864&_nc_ohc=nqzVfw0J8Y8AX_0beOS&_nc_ht=scontent.fmru7-1.fna&oh=00_AT-fNJTFXT1lERanlhAlM3rlZBL1_8OHe6O9tkDNNCKKIQ&oe=61D83BCF",
		price : 80
	  },
	  "f129": {
		name : "Briyani",
		desc : "Quality Briyani obtained in veg, non-veg and halaal versions.",
		img1 : "https://media-cdn.tripadvisor.com/media/photo-s/1a/88/3c/1b/kannaas-banana-leaf-bamboo.jpg",
		img2 : "https://www.yummytummyaarthi.com/wp-content/uploads/2013/07/1-1.jpg",
		price : 100
	  },
	  "f130": {
		name : "Dholl Puri Massala",
		desc : "Have some pairs of Dholl Puri with spicy massala curries.",
		img1 : "https://indianmasalamn.com/gallery/img21.jpg",
		img2 : "https://restaurants.mu/blog-admin/wp-content/uploads/2018/12/Sept-Cari.jpg",
		
		price : 110
	  },
	//Drinks
		"d130": {
		name : "Alcohlic Drinks",
		desc : "As alcohlic drinks we have imported brands and also our local beer",
		img1 : "https://images.theconversation.com/files/2982/original/3600947113_fe7208d8a8_b.jpg?ixlib=rb-1.1.0&q=45&auto=format&w=926&fit=clip",
		img2 : "https://i.ytimg.com/vi/HBEdwO-8Uz0/maxresdefault.jpg",
		
		price : 50
	  },
	  "d131": {
		name : "Fizzy Drinks",
		desc : "We provide variety of fizzy drinks at lower costs.",
		img1 : "https://5.imimg.com/data5/QR/LR/ZW/IOS-44897149/product-jpeg-500x500.png",
		img2 : "https://static.toiimg.com/photo/59896244.cms?imgsize=444506",
		price : 10
	  },
	  "d132": {
		name : "Coctails",
		desc : "Have a refreshing taste of our colourful and multi-flavour cocktails.",
		img1 : "https://www.orissapost.com/wp-content/uploads/2021/06/cocktails.jpg",
		img2 : "https://vedcdn.imgix.net/images/product/large/mixed-case-of-six-23124755.jpg?auto=compress,format",
		price : 15
	  },
	  "d134": {
		name : "Mineral Water",
		desc : "No drinks can match or be better than the taste of water.(Price/Bottle)",
		img1 : "https://media-cldnry.s-nbcnews.com/image/upload/t_fit-1240w,f_auto,q_auto:best/newscms/2017_20/2003046/170515-nbc-water-illo-brecher-08-mainart.jpg",
		img2 : "https://cdn-a.william-reed.com/var/wrbm_gb_food_pharma/storage/images/5/2/7/4/2274725-1-eng-GB/Bottled-water-the-next-big-zero-cal-beverage_wrbm_large.jpg",
		
		price : 8
	  },
	//Carriage
	  "ca135": {
		name : "Vintage car",
		desc : "Everyone seems to know someone with a vintage car nowadays. If you don’t, there are vintage car clubs who are happy to drive you in their beautiful cars for a small fee",
		img1 : "https://cdn0.weddingwire.in/vendor/5428/original/960/jpg/wed6_15_75428.webp",
		img2 : "https://cdn0.weddingwire.in/vendor/5428/original/960/jpg/groom-groom-entry-baraat-wedding-the-groom-entering-the-wedding-venue-in-style-in-a-vintage-car-kush-mussorie-1_15_75428-157649026663480.webp",
		img3 : "https://cdn0.weddingwire.in/vendor/5428/original/960/jpg/pic-002_15_75428-157649291742265.webp",
		price : 15000
		},
	  "ca136": {
		name : "Luxury Cars",
		desc : "Your entrance at the Wedding ceremony should be fabulous and unforgettable. We have a fleet of beautiful cars which will be a wonderful ride to happiness at very affordable prices. From Classic to luxurious cars, we have a huge range of vehicles from Range Rovers, Rolls Royce , Bentley, Mercedes, BMW, your entrance will for sure be Wow!",
		img1 : "https://www.thehindu.com/life-and-style/12u171/article26386074.ece/alternates/FREE_615/21tvmcar2",
		img2 : "https://www.thehindu.com/life-and-style/qsm7jw/article26386095.ece/alternates/FREE_615/21tvmcar7",
		img3 : "https://www.thehindu.com/life-and-style/1izwz5/article26386089.ece/alternates/FREE_615/21tvmcar5",
		price : 12000
	  },
	  "ca137": {
		name : "Horse Carriage",
		desc : "Pure romance, arriving to your wedding in a horse and carriage would make for fabulous photos and memories. If you are friendly with a farmer or horse owner, it could be free too!",
		img1 : "https://mauritiusattractions.com/slir/w640-c2x1/content/images/gallery/1419/wedding-horse-carriage-ride%20(1).jpg",
		img2 : "https://mauritiusattractions.com/slir/w640-c2x1/content/images/gallery/1419/wedding-horse-carriage-ride%20(5).jpg",
		img3 : "https://mauritiusattractions.com/slir/w640-c2x1/content/images/gallery/1419/wedding-horse-carriage-ride%20(4).jpg",
		price : 25000
	  },
	  "ca138": {
		name : "Own Car",
		desc : "You can bring your own car too us where you will be benefitted a free colourful decoration from our team",
		img1 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t39.30808-6/245393286_1032850944180905_2571097754767157678_n.jpg?_nc_cat=108&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=Ui4JsI0Mht8AX-srxUU&tn=3u-jR1bXj4OXCdCr&_nc_ht=scontent.fmru7-1.fna&oh=54b4e00b14afe0bb1c8d760bf3b22702&oe=61B8EF20",
		img2 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t39.30808-6/246162030_1032850884180911_8266803410868734086_n.jpg?_nc_cat=105&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=PsBJRXTLMJ4AX_Yej99&tn=3u-jR1bXj4OXCdCr&_nc_ht=scontent.fmru7-1.fna&oh=00_AT9QO3FwhVDxlDu_zX4FW-oBTKyQ5zB4MNkyo7MwgeMgoA&oe=61B8642C",
		img3 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t39.30808-6/245796956_1032851030847563_2141430464936647088_n.jpg?_nc_cat=107&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=gX47kI237T4AX8cu-CZ&_nc_ht=scontent.fmru7-1.fna&oh=5df36f721b0a820224a8f3d0f4e26be2&oe=61B8E450",
		price : 0
	  },
	//MakeUp
	"mu139": {
    name : "Bride MakeUp",
    desc : "Bridal make up including your favorite hairestyle",
    img1 : "https://www.businessupturn.com/wp-content/uploads/2020/08/Makeup-by-Cherryy.jpg",
    img2 : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSJP-AlTWf38vcvFTSRMl7qS6a6BksiU3-v-Q&usqp=CAU",
    img3 : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSitz7p0vzXnXakuJzF1q7Glw3u4BtsvBN3aHYWhhK9BJ2ys1nUZaXRCXErMO5bsrPOqJI&usqp=CAU",
    price : 5000
  },
	"mu140": {
    name : "Bridegroom MakeUp",
    desc : "Natural touch made by certified make-up artist including hair fashion also",
    img1 : "https://media1.popsugar-assets.com/files/thumbor/2i0fTmQyjV896-50Rjgefw763L0/fit-in/2048xorig/filters:format_auto-!!-:strip_icc-!!-/2015/09/01/961/n/1922398/netimgKuGUc5/i/Beauty-Boy.jpg",
    img2 : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSEhMWFhUVFxUXFRcXFxgWGBcVGBUXFxUXFRYYHSggGBonGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICYtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMcA/gMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAAECBwj/xABAEAABAwMCAwYDBgMIAgIDAAABAgMRAAQhEjEFQVEGEyJhcYEykaEjQlKxwfAUctEHFTNikqLh8UOCU9IWJDT/xAAbAQACAwEBAQAAAAAAAAAAAAADBAABAgUGB//EADkRAAEDAwICCAUCBAcBAAAAAAEAAhEDITESQQRRImFxgZGhsfAFEzLB0eHxI0JykhQzQ1KCotIG/9oADAMBAAIRAxEAPwBN/aNaS224B8JKVHoFRE+4j3qgpwa9u0IWhxp1OpDqChW8jmCmOYIFeL39ktpakLEFJj1HI+hFBpP/AJd01UG6IY4gQgtzg4x0p72FddF6yG2e+UFghEchuqThOkeKT0FXnsD/AGcWj/D0PP6lOvArQpK1JDachICQYJ5mQc+lWXsZ2ERZOKeQ4VqgoAcxCTGr4YElQGYOB50Vzw7oGbg+5QZAVtcW4Ek6fkfzpOi0ulrCnVphCiUoRIBB2KjOSP64qR+6ceBRqUz4gJAGrwq8WciCBG3Okfbe7dt2VKtblSXSUpUlWlUg4JRgaVDfmMbUlULX2JMdsX7EZjHC2/vdVjtU6L28Ke77stANmFJVqIJM6kHziDkdBTFjsNbaNTmpRjms/lXHZXhJSnWcqUSSTkkkySSdySTVgvrhSEEkbDFU+uU9SoiwCjTbssWoaH2bLXxA47xasgEnff6iqXxXg61sOeJGp6NKE7BKSFT5nEA0/wC2qlrt0qQhKwiHdKhqCjpGmRtvO9FcJsO8Q0t0hTxQC4UnwgnZKfKMUB13AhMCzC0+/f4C8iteHqQrQ4hQI6H6wauHDbAKSTCoAJMx0q28Q4P40kgEbZ3oi4s0oYUQIhNEc4uQWsa3C8pu+zHeqVAAUYI5RvP6Unc7NOd4G5GZznoTnrtXo/8AFJF0kclK0j/TANMP4AB/vP8AKY9ZA/ImjGoQQOpCNJpaSoOyXD1MW7batxM+pJP608IqNgVMqqKEgnt6IZ2od3eiWhioFZUbtDAUU7QwqirCgc3qKpXBXFWouCM0UjahzvRQ2qlCoX6CUKNfoVQqKKOK02KkNaQKtRdKoF8Zo9QoB7eoou0DFROip4xUS6ipOrVJK0gCSSBA552pxxTshbPKS6ppBXIkHCQBIKSBhW/Q7ULw/hbmpK8AAgiTM8+VNOI8KL5BcWrG2nwwPMjJrJeI+mVTqRcRJhEWPcWTSWEJSlKPhAUQkalEjfzO1AL7attOraW4kqEncCBOR7UuveyAWVErcVq3BWSCMYIPLeoV9jbdQAKAI5j9aAKr5i45e90VvDs07FKX+310XFdy0lSJUJJJCpOFIMeHHkai4Hw1Tj6n3ANS1FR6STmJp+xwENEAfDyp5Z2aR61qSSiBjWCUTZ24SnArd9bd4nTG+9Ttii20CKM1siEEv0mUkt0+DugASnwmeYG30phbMoSnwAAco2xjFLuNtaVeGdTkDAJPT03Iouxw0kdPbmaBTqH5zmRYDPvq9EV4lgcDlauG5PWNvLl+tK+0atNusDoPzFN1nFJONDW0seRohMGVpglecdrlht5taTAEH/Soc/emXZt0LuCpvVoDaguSSAoqSUCTOY1HHL1ErO2n2jjCE/EpYEeukT74+VW7g/DQwjQlRKZJAIGCTJyBO+a22CAUOoSCQmjNSLrhmpHDVlCQLm9EtHFCuHNEt7VQUK4fNQINSXjoSkqUQABJJMADzJqrcX7WtNN6mSh1ZMBIVt1UQMx+dagmwVagBdP3N64Nefq7R3ylBRWhKTsEoEc5nVJn3296lPaW76t+fgPIwQfF1xiifIesfOar1GaKSMVRrXta7utpCvNJKfoZ/ZFWXh/H2XPCSUK6K2PorY+8VRpPGQtCo04KNuKFVRVxQ5oSIua6aFaNbZqbKLpylzm9MnNqXKHiqBUpIxULlExih3qiiv8AY3OhpKVsOICEhOAHBAEY0EmjWLtpfwrTPRXhV/pVBo0ConrJCxC0JUPMA1A0iy26pTcZIInkbeB/9Lru6jU2Ki/u3SZbWpHlOpP+k7e1bU+4j/EbBT+JH6pOflNSNiFmAfpM+R/HdMoW7Ywf371q0XI8xvXF3xxhLfeq1hEwFaZB9IpD/wDk9sFakrOnzBH0igktG6dpcNXqNMMd4Hw7VZnXgmDRjVwIqn33G21IlKwZ28/StWXGpTvWW1ocsv4UgQ4QU84ksKUCHMEhMdcFRTpO+EyfSiNYAAHICq3f2ClKQ8oSEz18IXExynAn1o9N1NCpOGpztyfufsZU+VYCcIx56knFb5IBnfpR1y5CZnNU/j15AJ5nAPn5UUS5wCsQ0Sq/ZEv3mr7tulUH/Nsj6kfKvQkHFVDs9Y6fAN1nU4f8u8ep0wB0k1bRRwRslngzdTtV0s1w0a6XVlDQrm9ToOKHXvVc7d8dXbtJS0QFuSJwSEgCSJ9QPeoBJhU4wJVf7c9oO9eFuj/DbV44g6lDGeUJPXM55Un1DBJyNzy8jI5deeZ6CgeG6ACVaQeRKRv++lGWPC7pwkoQopOxj+pJ+tOtLabUrDnlDcYUoDUjYZI/CeXt/wA+8rHEteqcBYQfSZSr/cZ9qLd4C+PiSRHlE+UbdPkOlQjs2uAU46j6/seXnUFa8gqOpO3C5t7z7Mp8j85JA+gFSOXepII6en830z8qWX3D3W1EQeQMfM/nQTbxSNJ8x88UQVThD0wvQez/AGjUUpS5lMATzT78xVqrx+xuilIzzj5kD8ga9H7N8Q7xCkndBj2/4OKWrMEagmaL9inKq6YFcKqZil0dadFAfeo940EkZqBRSkYoR+jlUG+KtUvWUipEiuUipkiigIDisCKQ9ruKot2oKilTh0iMmMao9qfPvBCSpRgATXmXabjYfLcNK1hxJBUkgQDgJPOcVmq4ARuU98K4U8RXBIloz9kG4yhbvcNtOrQtMoS4SmFmfEke4rL+1KkthFolBZWlDpKhBViAfLIM01dcunLlkFCWVhJKVZ256v6VD/dK3HrlDz8ODxynwhR5SJ5UlphejbxAbDnOAhoOXOP1aSejAMjO4OUt7SvPF9pp23QkI0kJb2UOecVHxIEvg26QgECUT8J545elM1BSUt61hZH3+Z96FubYKWlQ+IbEYPoetZ0g3WmFpa1hAgBwtME84JtzByOey5uuMlToJWvCFI7qCEBSlArXPM+EAGmlpcgCSarVzbO5lQWATHJSfKOdQm8VAA32rIbELncRw4o4Mg+42T+6vdaoBxzqtcR+2c7tJEzCZOJrq51ARqid439BRXC+A920ErJ7xYKiZktndIT5g/UUxSbBkpCqeiiuz/ClsiXXNZzAGwn2HLFPCqlvBr7vUHVhaFFtwdFp3jyOCPI0wNE3SxJKnYNSqqBmpoJwASegqLKFVvXkfaq+Vd3StOUoPdojaEkyR1kyflXp3aZTjVs8sJUkhtUGDgwRM+VeWdnUS4kDmR/x6UaiBJJQauzVdewnYlJAefEn7qTsBXp1pw5CQAAKC4MyUoA8hTy3R1FBn5jpKaj5bYCjVwtBGUg1ErgrQ+4KbAVG5Rvlt5IIqOO6rd32dZVMoGZnHWqR2o7BIWkqawrkK9OuKWXSaXcS02TDWh46S+c7uwcbXoUkjSczt5etWPs3xHuHEgkQ4YVziSIj97q54qzf2g8JCkd4kALSfmK8/wCGoX3ydRCBMat4jeCASD7TTjH62SkHs+XUgL1pVdtVEnYegqVqltkysdNCJ3ot3ahU71AopTQz1EE0I/vVql7AKx54JBUowBuaHu71DaSpZgfU+grzfi/aZ66eDLCCEAzpVgqA/F5eVEdUDETg/h9TiiYs0ZccBTduO0ZdhpAVpJEbjVn6jlHnXF9fPuFhnuAhUoUkkGZH6Urvrp9+5QnQlC2uW4wdz1ou6ubp67bbK0BSBKSBgScz50mXaj0sr1DOHZSYxoa0aWudczFrG2ZsT3o3iTVyq8ZbcdSklJ0lONI9+e1J+J2BQ+93rqlrTBCvxA/iJ9NvKpbm0ddvdD70KTkLHSeXQ71Dx6zeYQsHxNuKB7wmVHbc+wrJdeAi8N0HMYHtBLRYCBczIJE423zlFcQcbShtbS5BgaZnPpW7+9Mo1ILZMZ5HzFAcYbtiy2pggOYBTznzFc8eef0NJfSAMeIZkfpiqst0qQdo7XDpWd3DdHXbhSoalCDzHPzoR5tOoOJiefn50PxVpDZbW05rBjEzUV1fjWNCCJ+JJEQayMWVjhRVpgbEHaMenonHBWg4ouFOE4TI+9zPqP1qfiD0OpzAAPz8/kaD4XxeR3cBJHUe8Y51Dc8J74kurUUndKfAkmMDqfnTDIheX4zh30KpY/u6xzUfZd7vHrt1H+GpxASeSihGlRH0qyVDa26UJShCQlKRAAwBUxFb3SimZpz2a2WrI8ZHLYARHlz/APY0mapvwmdH/sr3GoxUmCtNEghccOSXrl8OGW2zoCCJCtSEkkiMpGqOmTSy57HWqrtLrCAjEnuwkNFQJgqA2J8sYzThu1LYKjElaliQMEHw5g+LMzXPDLpTeouR4oMxkJyfFAAKpVHtNRrg0R4q3Nc46heLD3760mvu0Krdami2RoxuPFzB3iM4oez/ALQUk6O7UF5gYyQJ39oqHj3H7dL2p5I+BJOqYGVGMAkn2oZ28tLiFNBO8AoKgrVE/CtCZieUnyq2noyAo5o1Q4+SvfB+0CH0zBSeh3261xwriyHFvmTpTojoI1JJ9z+VVfs625r0zIGx2kcprOMabMLAEd4ZOSZ6D0EnHmaz8924Rhw9LS4bkCPG/kFanuKtGMjO0nzIoZ1aVbHPn69eQ238686et13MAEIA21KA+hrpPCry3khzUn1n86sw7JhCgsNhbtR3a650jSrZUjP/AD5V58hQ71BV+JMxuYPzJ5/9mrXx59VxaKWRC2lAq8x1+R+hqktFS320DmtMeYnM/nR+HMMIOyV4m7wea9WVUjdRRUyKCUVcPbUMjeiHjUDe9QKLtVBv70asUE/vVqkTacTvXNV3oCkAGAZAEb6RQXB1vOuOXLZQlWxB9OVbu2Lq2ttPejul/dBznyoe84Mpi3DoehSolKTEzSRk35r2zRSg6dA1HS2ATIGxHsIvgXBnLhTjyntBBMnmTz9qF4NYa3XCX9CkE+IHPmfSgLe4KWT9qQTskHf1qa3bZDBWtR7wzAB+WK0XD7YR3tqDX0rEhohot45Hkp7dhC3Hi46ZTOkzBUc86L4+1dIt0d4oLaMRvI6An9aUJLPcn/5Z/ftU1+q6DDfeKJaV8PP0msudHv0WjTcarTIgOiHAbD+X1RfHHbVbLamBpcwFJAA9ZqPjarlLbTb8aMFJ5nyJ6xXPFzbONs9yAHDAUnz6n3rXFnXgWWbv4ElPunY59KxqQ6LYFMci4w/6x/T73WuM2zSVNG3OoqAOkGcig7ta3XwNIQvAiYyMyaK4iwhu5SbQ69iAMweYqF1Sri4JMNqg+WR+tDJ3KLSMNDiZAabn6hJ3HL8IEurQ4VH4k5I65zVz4depebStOORH4TGRVIWkHVrJ1cvM85qwdjiAlYBzqBjyiKPQdeEh8d4cOoCpu2PA57lZRWGsmtmmwvIKZup+CcZQRo5gkHyM5oduqs1fd0t0kffWf9xNYfIEhFowSQVe+OXwSkGRkiJ5EZ09IMbmoe9SpvvFKCYCYBUBqMBU7jEEbZx80RvtQ8aJAKdQJEyYKdIyFZjnW3V43J5kTIMc4jeR9APQRcSU42mA0DzWX/CGXCXVIBKpkfFII6EZGwjzSMmnVh2dSGg2pLYZ30JQAM5yIGfaq/qUkEk6lc4+ETqGkHn94aufiiPEoWPgPH0utoQVAEJyfIYET5RRaVSN0GvTxpCbWTCQtIA2AHXA86UdobBL7kH7oMdJPOKb2d40lZBWDHnQ77yVLhKhIk1HOlszuhhpDsHCod1wG7ZUTb3hbOdSSgAKknMJMnEDIMx54hvHrhCyEgqTzOkI1DnqSPDq8xHnPL0RtLT6SlaQSDBB3B8jUSuCMpyAr0KlEfImtlxcMCFgANMXBVMUx/8AquhQ+JKjty0/niqV2P4bruC6fhawP5vI8/8AqvSe0BSltyPwKH0/fzpDwKxLaRgAFMqxkqPMn51ik/S0jmYUqUtbp5CUyNSpqM71KnaiFCUTwxUDVTvGoGzmoFFIugnjmjFmgXt6tUk3G7B1paUOOk4ESSQKCubgBQQVkjGZMD0p+5w0/wAUG7lcyJJ2xyGaB4oyyh+EjU3iRv8AvlSQaRgr6BSqzpaDJ06rDon8IC+bSlUIVqEAzQiHh6Gi0tlTstJnMhHKKF4slRUo6NK0nYcvKsAGbpg1HNHWBfF/BHIabIMK2E+p6Cin7l7um0Oz3QIIxEjpPpVZtnsKIq2M8f8A4htlh0AISU6iNyPh9qp4Iyl/na9BAkXJ5gAESOtT8baZW4yLMeIhMgfi3Hoa5u3nHLhtu8wEQk8setcuW5TdlVkCoNwrqB1/SpbF1u7fcVdK0GDGY8QmaHO6E0hjAcgNNzeoCf0US/sLpSrb7RKM9YB3EiuLa2Fx37xVoWJUAD1/7rjht05b9442jW2dSCojG5gz7VyqxQbVVxrheuCnlBzUwikaTmD0Wh2SdyCNv1S4FGlQIOuQQfLmKY9m7kJeCSmNSY99wflQj7wW220EELBOeo5VAl1SHQpWCnSD7GPyrbDDpWuJZ86k9h3n9O7BXoK1AZJAA5nYeZPIedb4e8H2kOISUnUtp5CiCpt9BMoURygb/wCVXStJII8iPoaWNPizfC1KIYuNLT6t9Cx//PcHrEJSonfSOa6cqajgx+fduwlfP7+/fswnbZqocXbKLkiN1agSnUAlYJMp3jUIx06VaBfIU6tuRryVASRM50q2UDIMjcGaE4rbgutE7wQRzgwUkjp8XzqF2psozGua8AjPocFB8JakpMwB4umAVDIOU5xk/rEl4gjxc8BUknGpE41dYxPyqws2qUJnmqMiAZG09aXcTtNRJHPcYGDzjGIUfc0KbJ4Oul9yoBKgTvIMHfkRIxA0xIwSmPgQZV2LC7lgpQCmFE6kkpOqVDcGQIH1qLiCloRByY0oVnBjwj1AiDsQBsUmR+zPB3tZbddWhuPAtvIBwYUkz15edGpCWoNWdYF+5SDg93bK1oQs4MnUog88j8VRW91dd53h7xBO4M6Y6aTgeuDXotv2SlKdN84ZKs+E+ETEYyeuRVZ4/ZPWqVOG6QsD7qoMxJ04G8JHX4hRHtGYQGvYbB+L4Tbhl+G1JIVOoQeurefzp85fgivIkcVW7pWlCkQZAUCJV/lPOdqvVw4pOJoFQGmBCIxwfMjCB7Rv6iEAx3hI9hlX0H1o5xOlKUzmBPyH9TQDELfSScISr0lRA/JJop5XiMbcqxTEujksvMMPWfRYalScVBNTpNNJVQvmoWqmfNQtVFF0ug3d6MXQThzVqkjuHlKdJdUdQkE+nShNeZ3oi3QnUrvCcT7mstXwkqMTIxP60lJNp+y+liwIA2HUO5ZY6yolswYJ9qgdlRJUrPM9TWCSTBI32xXOOZ9KoiCtaekT2JRfoCFSPvU07LtIddS24rSkg+LzHKobxgLTppUgaZBPiTtRID26ZuuPxLX0Kxc2zTgjYq4tOPWqnVsHU2CUFUY8q7YYt1WinlL+3JMCf086T2HFFdz3J+BSgSeYyJ/KmPGeHs620WhLijBWBnxfuaWIgwUUOkh2JIMjcCMnr5KUcRdatv4dTcJcMhR3g4MVnGeFhnui2vXqAVG+fQUQ5drvHmrd0BrRg9cb77UI0sW12TBcQ2SJ9PpNVC0x7gZAh13Fow6bC/ct3bxunQUJDZbRn1TSR1ydSlKJUSPfqabPsrcS7doVAk4G8bnPvS0qSQgIBKslY/Krbb3haBaBpFot2dXZhehWCwptCk7FIid9qD7RWhWyoJnUMgDOoAglJHTwg+RSk8qM4esLQjREFIiOWKcpCGxBSVKjUcHbl79PbrT82XigCKpcLQT5FVVjhNw4llatTbiUqT3iRPhAhvUZHijUnEynTTuy4S0gy44S5gkDRqBAM6lc/PpFJOO9p3O8DZ8KecdCPvHcSCMCD0oRPGHisKTCkpIJIJwAZJ8TRBkTOrV8XlFbo8I+sSKZjmSD+DHem+Jq16gBI5xGkbkxJI/TqXoDbKDtI2BMgyB1EDn0rT1ifuETB59dpzIzzGedVaw44UoH22lICZS5BCQlcLJWlOgqIURpKDnSTtk9HHCkAqMpAnWNEAAhOpzStSSMolSVEDWJCYmo7gK9Nmuzx1eg8rZuIBXPPEPY/Q+Wnk4EHtIPrjmUl7ReHQIGnUkff31HYryohOD0KiN6PKShGoJkRmJ5cxSzt1bwlq5aA0pOlwDlJOkjlpkkeRUPY7s92qbKAlQG2x9J96XpdJoc0pl1fpz2LQ7VNJ8KlKBH3VAR5R/1UQv0uYASfQT9adXN7ZOZU02VZGQPbPtQbnFLZHwIEmYj+nyo73uMQVpvEO3UfcIRocUB4JKf5owY6DNCX17IKlGAMk9IzQl7fd4Z2A5ctsflQDDRuHQgz3SPEvzgiAfU/SaARqMIRqWTbhYJb1kRr8UdE/d+mfejK6Wa4BpgCEstUQihyakQatRc3BqNqtvmuGqii6XQLhzRqzQSt6ipVS2uQsEjcfEOYNdlIOaVKRCsHQv/AGqrrvlddKv9qqTLZXv28VAioJPvz6j3HCbhswSBgbmuwkaSSc8hSr+9FAacJPOpAmRqnVVRpyjt4ptSzL+Xj+yYXLSkgTGRIHr1qt8S8KjPOjVurmZJ9aF4m6FDxCSmt0hDrrnfEKoqUDsRe+CmPZ9bZcSl9RCIM024cpxlarlhJUhClDUdtM4n6VVGlYFWC04w62z/AA0gIXk8zB3qqrDMhAoVCW6czzxH5Te1t0XDb1047ocBJAGOWPPyqHh3FQ1butLbJLnwrPpEyag41w5ttTaWFFwqAUsDJn296YuXH8ctq2QgNBA0knfAzS5iOr0TIILeldueWkNx15CX8V4ephDRKpDsKKRIEefWhrhWpSnG4SlIAI9RBgUay8GLgh4lxLeoDnGMQDQDjSgO82QtRx5AztV9v7otznx2Mmcdiu/YjQ3alxSsSo5zgdAM7CcUab9CxqmSSSITuPDBBKcYA36n2qNld/Zd2kSEqlMjGkyAoHUCCDOdsjIxRjLzj6wlBZGvSEpTqhJKEqgjokSYGwgZimWkaNS89xTdPEO1dZ7ll624+8NCDDZIClHSgFQ3B5EBCvhEj60xRwJ4lJS4CEmCQ+4lRIAKkhXikgnSeQMb0zY4Xw9Ke7ccQ4pO+twROcpb2G56nmTIBpijsraKEtpSJHxIiYnYKa0nlzJAjnTvCcXRY3TrIM8nR/1cLdrZXL4jiKhIimIxhpJ/uB8nN8VUuId6lIW6gq1hI1K+IjBGm4EhWeSiRkeHGorFOKY+0Z1KRKFaPDunxfD/AON0RqTjScYzFXHiFs+wTpSHmRJKVFMxGUpVpAA56SgA6iNSsRVr5pBUHWoOYcbI0rGokLQtHxBMiIUBpUEqG9dI1jAcYM2Dgc9RIgR1GCLuDi4ArNB1OqPltECZ03j/AI6pLHf7XBzmH6XQJCH47xJKLIsBXic7sIA/AClevYeEgYgQNQAwnFUskHqR6f0ou8bUpZ1ggp8AChBCU7CPr70bZ2ciuL0WFxbuSffLCmjURv7z3/ohw4cQ4qRzKZom3XBkyr6D5Dfn0olNp0H1ppwvgy3CEoTJ39PMnYChmrsrFGLoFAWtW0DZKR18h1q9cD4B3bKgoQtzJ8o+Ee1HcF7PIZ8SvE515J/lH6/lTvRWQDkrDnDAVCfbUkwoEHz/AE61GmvRjZJWnStIUOh/eDVU472dUydbYKm9+pT69R50djiRdY1CYSQ1ImohUqa2rUNxXLdY+a03UUW1mhDvRKzQ6aipBcW7HLSCUTpkRPiEH0zVcu+EOowpMjy5e1WlniTwQVtlYCDnMpHsalb49Ml5tC9UAqHhVHl/3Wzxjn/5gDu0X/uEH1XabVqC4v8A0n7HZUdLSSNKzAH4uZrpbhaSkGZkyeWnl+lXJ4WbpIkoMYK09fMUC72ZSsS0sKHRKgfoayRwz86m+Dh9neqZHGxiztjg9h2ISTQlwYPyqFzh4CT1ox3sy83JSqPJQI51Bc2dwncTicHFUOEH+nVYR1nSfBwHqnm/EKVVv8WmdWJFx3RPokesA6TvTDhrresd7JTtI5edAcRbUCCoR/mmumzyqqtOLHyIPouZSq9NwG2LQrRwl9xhX8U0jU2CUgqGIO00U2x3rTt4pzQsK8KU4z0HOlNvfuJQLVSgGyoExyBOc0bxK0QHQi1UXQEhSvvDUN9qRc2D7x1rqMdqOrBO+bDYqa3vki3UwtB7xwg61dDGZOahvbf+HeS24daU5gbeIchTFTn94uAeFoNNmTt8NJ2bkJ7wLBUVDSlRzEHeT7UP2R29aMwz27jOcXUtuVp+BekqSQkxMSYI9YFWTs5aKdJEpOoK7xaUhKoVIMEbc0/9VXGLVQcCCroUkScmDj616d2asA0ykataiAVrgAqVAmQNvSjUxI6vVc74q5oeDMkjykwe/wCyNsLBDcBCAkDkB+fWj12LRyUgHqnwn5jNdNJrt1UCjhoi4lcF7iTZKbp9bEk+NvmYGtI8x95P1HnyrPF7JtqX2ToQtOhYTlIBHgKUjBA5A4xHSLFxO4gGqlxFLqLdKSlQkgqxJETAIBwTI35A9aT1PpvDaZs6xG3b2jbflay0+m2NRyEG7YquFaFlKlpAShwBI1EHZUfzJHkc7Unt7R0qCGwdR5dI3kmAAOZOBTzh6NIAA3O/+bQ4ARIJIxkTyEdBYrK1SFXCwBKntBPQJCVLn1Woz/KKPqIBJQNcJXwzgIRl9wqI3Q0MdYUs/oPerpwRTSm/sU6QDlMQZjczkz1pClOR8RJEKTEjwmZJ25HnyMzTDh3EilIS2lBVgeESTzyRnAO5iZkdCNtUB3Sx2LL5cFYUt1Mhqa7YQVAFQ04yPPpRSERT2gOCWL4K4bTUpRXWmuoo4baEEuSHifZll2SBoV+JOJ9RsfzqpcR4I8zJI1JH3kj8xuPyr0oiuCisGnyRG1SMrx541tG1egcY7KNPeJH2a95SPCf5k/qIqmcT4Q7b/wCInw8ljKT78vQ1kgjKO14cgHNqgTU7m1QIqlaLVY61utM4TJnOCAc0lu+HqRrbEeIAieXmmh+H8eOsSB5EGRB60ya44lxZACSuSNpBTHIUk5j2O0uERn9uaYDtwUlRbnxBRIUBjzI61C24oRpwoTn4SPcUeq9CVkqTJmI9qgQ8gr8UDxc8/StNJJRf8Q8NiZ7brGuNXG2tRGcYO3ka4uePLKdJaQUDc6IO/UHFY2y0pwwQnfJ2J6VC42nxDKUkAKg79fWiTCoVZuWjzHolnFuK6wQGkJB6J39zS8262wkrHxiR6cqYC2QuJOAeX5UVxH7UJTgQQBJAAnGSdhRRAhoWqTofqwO/9UBYvoTq1p1SPCehpzZvv2qe9CRDiYSo5j/mhuO9m3LR7+HccQtQSlX2Z1JhWwkxB8iOnWmNhw0BSU3DhIAkNxjO2ZoVWl5+a6NLjqRaZNt/fgtXnD0oYbdQ6VuO/GlPQiTtmp0suXLTbYa0IbB1LIwTzJ60TatMsnW0mVDEqJkDnpnHlRrRcdAVKkIJjGSeonYTG1CLIubx3KO+J26Ik+9hbxlZYWwtXRI1q0+IqE+Ep5dBtVw7LKBSoAz8J3ncdOXKqjw2+VK1FGuZT4lQU7aT545VY+xbKkF1WrUiRHruUj0mo09ILmve6o4vcZJVrCYoe6dgUS6sRSW+uKM8wFimNVyhT4nPTP8ASjW2QdxPlv8AMUJw8TJ6n6Cmlug0qWyZhVVfLktHZ1GtK0nRG43EbkA/d2228toNseBqU3lQClOvLUY1TqWQIBGxSkfOm7KBFHtNwAByinKdMFsHdKPqkCB7z+UotezyE7rUecbDeduZzvTa3tEo+ECiAK6AozKLG/SEB1QnK5SmugK3WTRYhDW4rBWq3WlS6rhSa2Kw1REhTdcxUSmwZBAI86nNYaotlXKqHG+yCFypkhtX4fuH/wCvtjyqm3PCXmv8RpSRMAxIJ8iMV66UzQfEHAmKxom6KKhFl8mIuFIMpURU9pxhSFBQUQRzobWn1qPvByT9K+jcZw1CsYeWEciNR8RfzXPp1Xs+mR75G3krMjiIB1haXNW4JhQJ6jrUKrtQMlCqr5t5z8NTG6IxqUfUmPlXmqn/AM4GnUXBreZ5bQPqt1jvTw+ISILZPv3umn98wCNJIzHl6mhDxBxwaVGEz93BPlNKX3CcUVZjw+9I8Tw3D0Gn5IJIjpO59TcDtMo3C1X16oa/F7D85TMXhACUgJA9z8zRnAbVT9w23PxqAUd/Dur6A0pTV2/s0tpecdP3EaR6qP8AQfWuS6y7TiGUyY2SfiXD02j621eJMApPqSBI9RWM3yNYAkgZjcA+VFdvlj+LVI/8aBMjBknb0J+Y6Uls2BOMGtluoSSuY1mIVovOINOwG1LbACfjgkqjPw7CaMF+5p7srJSYMDCSR97zP9KTWXDx+I0/4dZITmJ9c0pUAGEwykTlS8I4eXjBBCU415EjpHP1q/WSUtthKdhVbtbkCjP7wxvQ9aKaYATVy8gEUlubjUqBzNB3vEelScIRqOo8vzNU42lUeiE7tWYgU3t00vtz5Uxsxn9KEzTNtzkpV5O6YtJ2/fnRyRQbGT6D86LSa6jCCAkXrsV1WhW6KENZNdRXNbqCyi6FarDUalVcql3NbNRV1VAyrhamta6w1yTUKilmqt2juZUE9Mn15frVhunNKaqhT3zisYTz6msVDaESkJMr5qAQOVbNx0EVlZXvq/FVKZ004b2ALm6QcqNRJ3NZorVZS+gO6TrnrVlRpTJo1nCR++VZWVx+PaBwgduSPuuh8PP8c9h+ykSqvTextuW7IKHxOKK/bYfQVlZXnnLrcQToA61Vu1joXceIgShJJIMynXAkdYj2G1LAhTZhYiMEYOQBOxP7NZWUQYCALtnknPD7unjFxitVlK1AmqZsunL0itG/JrKygwtErbSypQFXWwttCQn5+vOsrKycJeocJihR2An9+dNLSsrKHTJJ8fIID0baJ38zRaK3WV0admhJuuV0K6msrKOAsLqsrdZUF1SjWaiBzW6ysuyO1aGFvVW5rVZWSbK4WlriuEmTFZWVC46wFBhJ+0N2fgTudq44db6UCPetVlVl5RMMC//Z",
    img3 : "https://stylosalons.com/wp-content/uploads/2018/04/groom-makeup5.jpg",
    price : 5000
  },
	"mu141": {
    name : "Guest Makeup",
    desc : "The guest will have the opportunity to benefit from a light touch up and quick hairstyling for a reasonable price",
    img1 : "https://www.makeupbyanab.com/wp-content/uploads/2019/11/MakeupByAnaB-29-1024x684-2.jpg",
    img2 : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgVFRUYGBgaGhoZGBwZGBkYGBwaGB4aGhocGBgcIS4lHB4sIRgaJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHhISHzQrJCs0NDQ0NjQ0NDQ0NTQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDY0NDQ0NDQ0NDQ0NDQ0NP/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAAABwEBAAAAAAAAAAAAAAAAAQIDBAUGBwj/xAA9EAACAQIEAwUHAgQFBAMAAAABAgADEQQSITEFQVEGImFxkRMygaGxwfBC0QdScuEjYoKS8RSissIVM9L/xAAYAQADAQEAAAAAAAAAAAAAAAAAAQIDBP/EACQRAAMBAAMBAAEEAwEAAAAAAAABAhEDITESQRMiUYEyYXFC/9oADAMBAAIRAxEAPwC2EMQhDEYAEUIkRQiGKEMuBqTYDeROIY9KKF3NgPUnoBzM55xXjlXEnUlKY2QHfxc8z4CIeG5xPaXDIDdwbcgbm/kNftMrxPts7H/CBQcrgep/aZ18Qo7oFzt+CSaGAruBloFvG0AweXtdit8yn/QPtH6fbPEj9NM+aN9nkR+HVl9+gw8lMCcOqEAii9jzykCAYaTC9u0IAq0GQ82pvmB8cji4/wB5mt4ZjMNiAPZYlGY/oLBX/wBjWb5TlFXhjqO9TcW3Nr28423DqhW6IxF98p1t0i0fyd8wvZtmXM1TLfUDLfTlfUSDiOEVUYrcHoRsRMx/Dzt3UpOuDxzMFIApVHBzKdgjMfeU7BtwdDvp0etxBGa4OmwjTJawz1HAVCwULcn81j+M4bUpjMy6dQbgefSaDBOock8xYGK43ikWkykglhYC+tzzt4bxiMc0QY4REkRAIgEOAQGODaAQAaQKICGq8YkivGIDCgghmAxMdWNXivbJsWW/mIALtCtFkQoCCiTFQjAYkwGGYRgAmFFQoAJhRRhQAWDDESIayiQxAz2gEzfavixRfZ0z3m7pPnyH1PhExrsqu0eO9s+UG6qbDoTzlK1PQ22G5juS2nID5/h+cFcWXKNza/55/SSi8KlUb3hcchDXEODox9Za1aGVdN9/WM08JqfDT5RiwVg+L4lBZKjga8z+dI9T4vXBPfYljc6m5goULD88/wA8o5Qw4LADcwGjR9nGxGJfvm6AW1GhE3FPh6ItlUASL2YwYRBbwl5UE567OqP2mR7QcESshUgBxco9tVbkfLqJN4IzFUzizZRmHQ2F/nLHEU76yLhffsOl/p+8rirHhHPOr6NHm0lJWHeMulXSU9dCGNwR56Tc5CO0bMdaNGACYYEENRABwCGoigIFEAI+I3jEkYneUvG+I+ySwPfbReZ87c4mNLSLxvtAlE5E79TmBqF/qtz8Jmq+NeobvVe5/Tqu/RBJuC4NWdu6LXOpLX8yw11l9Q4B7NDYkuf1kbeC9JDpG0wzI3ZNCxBPIsc3xA28jCbCqw1sb+BHrrrLGtwUo2uh9QYh6WXzG/50i+gcYNYHGVqGiOcv8rHMnwDXt8CJo8B2iRyFqLkY8/0H48vp4zOsoYWMZCW0Oo8fzSNMlydDvBM3wHiRUik5uP0E726eYmjBlLshrA4gwzCjAKFaHBaABEQrRVoLQAKKESIYlEiar2BPhMHxIZ62v6QWPhm1v6fabbGmyMfAzC46poxG7aE+A6SKZcojKcxLcvte/wD6xbC2p3J+n9yZXisV8tvz0+UeqYq6kja4Hzghssa1j8/oP3jiU7385DNXvop5qT63/f5Szw7A54NjRTPie8wGwJHnY2ljwv3gTqSdbTLPWJZrc2PzJM13ZjCFyLxU8Q5Ws6HwjFd0CXSVM0p8NhcoEXjq6U0LO1ltsPebwnMnrOtysIPG+0tOmSiBnYaGw09ZbdjK7P7QmlqyqSxIsvvWW29yenQ9NcTWrI9VMmUsx0RToqnkW2vz8Zv8NhWRMyE3tYgfqHSaz09MrX1LRdcJAJa+4At87/aK48q+yJbcEZetydvS8gUKndDKbHrKzF12c95i1tr7D4Tc4yK0aMeaNNAAoFghrAB/lCWKgEAIuKOswyZsVjMgOlzr0RdDbxJPzM2PF3yox6AmUf8ADnChnesebZB5KMxPqxH+mRTNeNdm84Zw9EUKqgSxGGXoPQQUwIWIx1JPfdV8yBISNW2RMXwqm4syDzAsflMV2g4IEOZTpsfI7fObihxehUOVKqsfO3pfeVvHqWZGk0s7RSbfTOZBLfAn9/ufSN1rb+v3vGMViSrMDyJHoY9QbMNeYlmbE1GIAI3Go/b4ibLhGK9pTVr36/nlYzC57WB/SR6X1/PKX3ZTEWd6XTvL5X1+o9ZSM6NVERcTKJCgghwAEK0OCADd4oRAh3lEkXiVUKhvsRb1mDVCUUnqbfv9Z0SpqLTFqn+G7Ea5jYHTS9rH4WmdGkmW4k1iFHS/roPkImi4IVejXPjpJGNolixtqLehH7yBg1Oax8vKCfQP0knEEvfpYeh/PWXuBe97sRmvchSxAA1OUanymbxKFGI+P7TV9jKWeq5VtQgyH+oX589LRU8RcLXgjCdkcoDrUWorAMGCkXB1va82nZ7hopi/9ox2foezc0agNlUlGJ72cte2u4sTLRnKbHTlMKun0dUccoultaM4ng6VbFxmHTlKpMd4ybRxZ6yUy3O+EYdm6FJ86g5r3AvoPITRcNqXB10BlW9W4uTIVCk75iHZQTqBbW2m+4+EtV3pFSswuf8Aq0arkpsGOucDXLYXuenL1kdxqfOUuA7T4PAFqFRGZrlj7JFJsSb5yWBNjfr05S9o8XwWKQvhqgzrYshur2Ol8jfUaTonw4uX/IjtGmjriNGUZhQ1hQ1gBIgEERUcKpY7AEnyEAKDtVigqMn6mB08LbzEcKx6oqKiuKguWdWIt3ja42tYiWtaq1d3duYa3nY2EX2Y4AXDOGK98g25rZDY/EfKZ6t7Npl/g6J2a4i9ZCHBDqBc2IuCNDYgEfESj7TUXRrpSDubnv3YWUFm08gZqeC4fKGN77Lc9Fj3EuGJWTK+oBvpDFpom0YvhnaKqqKK2HQIxKqVXuEjcDQWPmB4EzTKA9O4vbxufrHsD2doIQwTMRsWN7eQ2kuu6AZFtfaw8rybwct+HFO0uGKVXH+b6gH94MOLAE9JddrsKRUJIttv1F/3EpyOXp9f3il9E2v3EHHNZj0P/F5M4bUZXWou4GvkN/zxkLiVEmzDex+V7wcMxWVlB2P1lmZ0ulUDKGGxF4oyswOKVQB+k7eHhLK8rSGCCCCMA4UOFABq8DHSFDMYiFVxQ1UX8TMjxDFAAqosqk3vz6/C5ml4vhrpYEjqAT6zK1eHWFi1/Db/AI/tMq97NZ86F08JfXkfv+esPG8NCZX073veIF7nz0EmUk7qrsOp5D8+sTxSrnC00F9LE9BuT+cpKfZWdFDxugGSnUHMZW89SPhcN6x7svUanUBFxpY2sPrpuJL45RFKkqE3Om/h3tfTXzjnC8KFZDyYAD42I+X0j3ZEllGm4dxym4IdmzLfQ0iagtyDWtffUHnHuGcSWstwCL8m3HnIPC66+0Kn9X1G/wBpOx+B9m3tEGh94Dr1mTw6k2THw99oQzJ4yJhuKKdCZPTFqYsGqG6mIbLoI2z1AhGfIhG6++R/UfdvrsL+McqVVOgjrlMt22jl4NPvTmfaPEJ7ZUQe6MrE7nPlI3363/zSFwfFtTrK6GxU7/byjvarFq+JdqZ0AC6dRvb6fCNcEwrPUVVF9R5DxPhOj1HFb+qbZ2ehiA6KwI7yhrX11F4ZlfwnBsgzOR/lVTcAHq3M26aecsDKTM6ST6EmKSJMUkZJIlJ2rxWSgQN3IX4bmXcpO0eB9qnkD/zE/Br0yOENkBHT6/8AM0HYfE9x1/lc/PWZ3hisUKkahivp+COdk+IezxdamdQygr5pcH1DX+EyZ0Q8fZ0ocYsMiUndxuqlFJHVS7AEfH0lxha5IuVYD/MLGc14V2yxLFimHDAMRbKARf8ASSSOm81nCO2NCucjBqVXbK4tc/5G2b6wxo2vjedY/wDhosRiLKT4Sh4dUBYsxA0Y3Pi2u/lJ+M7ykX3mVx/CLjViR0vp6TK+xykkMdu+I03VERlYg65bXC2e/eKn9WTY8j4GYkYgixCsfgg9bv8AaSeLrZ8gO2vpKerUK38DrNJ6WGF+l+2FR1F6gQ2BOZGsPC4uDK7EcG/krUz5kqP7RnCcQJITUkkBQBcnNoABzNztNri2dBRwy4elTeqVSwyMQD7xPkLknwg9R0cb4aXc/wB6TuC9nVGGVq7lnYBu61gvSxtqbczJ2F/6d1GSpkPIMR95YdoWyUWyDZbC3IbE+QGvwmZ4R2apZ6bB3dCCGTO2UGwym4NwNx8YnVaERxNPU/6LStRKb2N9iCCDG4OKcFoo4CZx3dRnY63311kT/orbVHHxBH0mk088MKjhTxN/2iXBG6NMqLMxbzFouWc9YniejMOEIBGIRWp5haUfEcHZgb6W+c0Ei46ndTIpFSzF47GWO+g0A+5+kGAxVjfS/j+cpW8TVsxJBsGJPrp9Y2jHLpvaZ4aaSu0OKz6/AfnU6eksabsMPQK6sAtvhpvM1TVqjBSSLmxPQfl5r8Ji0Qe7fKAFB2VRoPMn7x10sHPb0jriMlQBtyb+u3x0m5wOJDp1FpyPiWJeo7VGHvNcWGgtoB8LWjtDjOIT3KrqPO/1kvi1dMueXH2bvjXCxqyaHwmdevWTS/3lTU7QYrnWb4qn/wCZfdlHeqKlSqxawKIAAO8RdmNh0IA/qMa42vRXa9Ra8Kw3tMO9V6jh1NgFKhe8EK3uCf19Zb4WnQph3rXfKEyKxzFnYkWVTpfTe2gmf4eclErrZhSfwF9Leg/7ZeHDioUY/p1HjoR97/CNeoS7l9kPBdkKNRjVekiBtQq5rAE3FgTYefOTMf2SQU8tAKCNbWykkdSuh+I9Jo1McV4/pk/KRkuzfFXJ9i4AcXJAB0UaZr9Li3mZoiZR8fVy606NgzsxYAAXVchuzfyhmY/GW9CmUQKTmIGp6nmfWXP8EXj7/IsxaRsxSmMzJF41WcBSTtY3hsdJlu1PFStqY0vq3U9BE3iHK1kc5QWYe6CW8+evp8pi0rsmKFQbq2b4EWI9CZdY7iGVMo3b/wARv6kAfAynWmdW/UfkJCNjXUeA4iu3tKOVke7DNa4Dam195uOCcI9glit3I7zNYny8B4CYrsd2nXDJ7KobBScpO1ib2v8AGaXE9ucPb3wT4SWdP6tuflvouMRVyyh4jjye6mpkBeLviT3Lhep+wlpg8AAOp5k7zNh+DF8QoFWLnUm1/r9pSYizC/Ua+ewPoPUTXdqqFiAPE+lh95jqika/LwmkmNkKhiXpOrocrobqfETpX8OHfE1XxVYZigyK55udWyjlZbD/AFGc3rL016dZ3Dspw8YfCU6f6gt38XbvMfUmN4KG11+BfFHLuqr8RewN9LG3KL4Dw32FMKxF9SbCwuTfTwiWxADk85VcZ4yVWynU6ADfXoJmmbProf4lUDVDY3sB95GkPAUmVSXPeY3PO3x5mS50SsRyW06bQd4LwoIyRmCFeHeMQoQmS8IRaxMDO8cwSgKq2z1DkVeb6XN+gAFyZR4jhDUWAHeGm+45eREc4nx8DiVNm/8AroP7P/cCtRvVv+0TbVOHLUcHdSR6HaHzo1RjE4MahzqMp3Omh0+Rg4Thg7qjkLnawLKGXS+mul78/CdewPB6dNNQoAGpYgD4kznWO4jg8PTrUivt7VWNFqeVlAOvv3tYbHfVdpNRjRpNI1vDOwWGyjOuY3vqAAfgBtE9of4Y4eshNEijVA0YA5GtydL6X/mXUeO05+nbvEoLU2ZV5KXY2+JB+sn8Ap8V4m+anWelTB71Uu+UEclN7s3gth1IlL/hDf8AsyXH+z2IwT5K6Fb+4w71Nv6W2PloeoEs+ytTEIGrhAcMWtVy5NMotnVQcwy3BOm2vl2Lh3ZvGKmTEY1MWh95K+HFv9NQPmB8WDeUrj2DNGs1TDMBTqgivQdiyqctg1FyLk30IbcMddAI8E61GexeCCUFO+WkFNv8qqQfVbf6oWAqjICDtYyt4dja+FptgcbSdHCFaDMpyuNsoYaNl3BB2FtCBeTgEyqAJlXTNY0tU4ygcU2JDEgLoSWzWACjcm5tpfWG3HqZsqNnZtFsCRflI7PTA7416MJN4VgmJ9q6hR+hQLacmbobbCKe34Vf7V6SsPRyjXVjueZ1vv5k+sNpIdJHabHMIJilMbJgVohh4/FLSpvUc91FLHrpsB4k2HxnKuJ4qpUqZ3Fi4zhRyU3sPPSdK43hDWosgIubEX2JUhgD6TneNwrZ0zhlI7rAjUdPhvqNJNFSVtVyxF9/sOUsUS9IMumv4TGcVhbPceB8772i8MWcBb6em0jTTBD0+mo2I6Xh4Dh1yy9bFY6cIUPnpLrgGBLFT1a3wMGxytZo+zuCyoBNTTpgCQMHhGTQiW1NLiTho2ZXtNhL2a3Uetj9pi8dw4jUCdYxmFDoVPrMli8IVORl1Og8f6f2i8D/ACMX2e4YauJRTfIpzv4BCCB8Wyj4mdkqkqu3KVPAuDrT2GrEM58tlv0Fz8SZZ8SxyopJ+EVVo5nChx+KCAlt5lP/AJElxUOoBsBbkeY8f3kDtDxg1ajIDoPeP2EjHEMqEDbu+Y8R6S4nO2RyVvSN/TcEAjUHaLkDgp/wUPVQZOvNjnDvBeFeFABoGC8ReGDGIWDCqVQis52VSx8lFz9IQMqu1WJyYSqebLkH+shT8iYAcveoWJZt2JY+bG5+Zmg4N2uxOGQIjIyj3c6lio6KQw08DeZ6C0Yiz4zxzEYts2IqM9vdU6Kv9CDur52v1vI2GxTpfK2h3BFx6HnIxMMGHoGy/h5wdcfjlSqoamitVdbWVgpAVT4FmW45gGehaNFEUKqqqgWCqAqgdABoJyv+BWGGTFVuZanTHkoZz/5j0nV7wAVChXhwAiY/A06yFKqK6mxysARcagjoQdQRqJguO8AbDnMgZqd/Mp4MRy8fw9HiWW8TlMqacs5JhkV3UOQFBzNfmF5a9Tb5zQtxCmP1j1lpxrshRqgsl6b8ipOS/im1vK05vj+EvTco9wy7i9x5g8xJmflDqvpmvfiNP+YSK+MQ7GZ9MHpJeHwgAj0nCy9up2MWjyGlECSKawAdqVABcmwEzPFscKt8ighP1ldSTyBOw+sse0FQinYczb5E/UCZgswQjMNNgNQPEnmZNPouVrINZjUYBRZjoeg6k9Br8pDrYoK+RDdRpf8AmtzjFTFWJCnfcxRwTEBhz+o/4kJfyW330XuBcPq/IWHK/lN72bwCZVdSCPoeYPjOf8MoADvGx+cv+GcQfDuGS5B3W1lPwGl/H/iX+n9LSVy/Lw6Q7X0EUNBYSDwjiVOuuZDY/qU+8P3HjLByALycz00TT8I9TN4SDTpFzc2sNv3Efd8500X/AMv7QVamUaTKq/g0lAxGJVFNplWLYqobkimh7x6n+UePXoPMQ8fXevU9kh3948lXmT+3OTmVaSBEFgB8SeZPiTrFK3sb66KzH8LpVD3lBIFgQADbpccpVYnssCBkdrDrqbefkZpcGmZpb/8ASi0pavCWpfpnqNlAUCwAsB0ttHLxXE0yMDy2P2jIabTWo56n5eC7w7xu8PNKJG7wwY2DBmjEOXmY7eufYIOtQX+CPNHmlB2zpZsMT/I6P88p+TRAc+EF4Sw5QgoqIG8XADsv8C8V/hYlOj03/wB6lf8A0nVQ04j/AARxOXEYin/NSVv9jEf+87UjaRgOZoM0bJgvABy8MRKxjF41aYFzqfdA3P8AbxibwEt6RIcgC5NhzJ2mW7RrSrrYISw91wQtvDUEsPCw8DJVfFl/e25KNh+58ZGaYVy/wdE8P5oyD0mU5WFo4hmjr4ZW3Era/DCNVPwP7wnkX5C+F/8AkgAxStEujLuCIQM0T0xaa9MPxvibvUZf0o1j1JtrpyF9JW1cS7i2wB1UffrJ2MKPXdicoZiL+Win5Stxz6jLuDbTnFSxlS+h1eHh1DDW97fAbfKLp1WQfUfX7mN4XEsi2694eDcvUfaTWw2ZC3Pw8ZJQMPxMMbHcaXlzSq6cjz19N/TeZnCYNi+2281HDcO7myA35nkPMzaXk6zOk6eIewzuHBpMwcbZdwfL5f2m4wpqui+1IJG4UWBPj+W8JD4VwtaYva7Hc2+nQS3zBRObk5frpeHTx8XytfobaCZnjvEyCETVm0AEe47xtaamx1mIw3F3FQ1GUNfSxuCB4HlImXT6KqlPptuGYcUksNWbV26np5Dl/eOV0vKvB8fot7xKH/MLj/cPvaXtEq4urBgeYII9RNHLXolUvwjYFLGXinSQ6dOxkobQBlHx6nmRh1Blch0HlLnia3BlLTPdH5tpHH5M+VeMXeHeIvBeamI3eC8bDQXgA5eQeMpnw9VRqSj28wpIkq8ImAHJVMOP8Qw3sqj0/wCViB5br8iJGMokIHWOxoxaHSAGx/hbjRS4jTB2dHp+ozj5qJ6CR55Y4TijSr0qgNsjo1/AML/K89J4fHC+R9L9dLX6jp4yl4IuVMWqykp43I5Rzrew8uUc4/xxMLh2qtYn3UW/vOdh5aEk9AYn0NLXgz2m7R08IoGj1WHcS/8A3N0X5nlzIydHiTMS7tmdveP0AHJR0mTfFPXqtVqMWdjcn6ADkBsBylgj9Jx8tNnbxQpX+zVU8beSUxN5lqNc9ZOoYgzHWb4maAVLxyVVLESXSrykyXI89IHlIGI4apBy90+H7SwV4d5SbXgnKfpzHiXZmpSuzHMg1zAG+nVZV4DCIzai/M3OgHQeHU+lp16ogMoeIdmaVS7KpRjzSwv5jYyv1W/TN8KXcnOuMUbNm5Hbl+CHwvEsTYDT5dJf8V7I1mIyup5Xa4sPIXlpwDs0tHVjnfqRYD+kfeU7S7IXHTf8DHD+AF7F+6vTm3n0muweBRFCqoAjlFABEV8UAN5m7demyhT4Ps4UTO8a40EBAMjcW41a4BmNxmLZ2sNWPy/vCZdPEK7UoXjcS1V9T+dIhRaIpU7D6x9UndEKVhxXTp6BE6SXhnZNUZlPVbgn86RCJY7EXig/y5ysILvBdoqyWDlX8xZvUfe8t6Paamw76snwzD5a/KZAOOfLWILeRifHLLXJSNrXx6OpyOreAOvxG4lLhK+YHwZl9D/eZbE1spFr5vDcS74NV0ZTuDm6aMB+fGZ/Hz2OuT66LW8O8bvDvAQyDDvDggIK8K8KCAzD9s6OWuHH60BPmvdPyyzPkwQRkhQ0OsEEYCyJ6G7Oo+LwVB6qq+ampDI2VxpY69b7wQRoCJxXBYxFAA9qq+4xyrUUdCb2YSnx7NjaYp1HFKpSuQlQgK2a2uYHTbfXc6QQQrwc+mKfFGk7IxU2NiUYOvwYaGWWG4grc4IJzVKOmKZYUsReTKVaCCc7OmSbTrySmIggiKJFPFeMkriIIIwHRUvHFeCCMkDERiowEEEljRBxWMyiZziXFCdAYII5Joy2Pxh66mR6AsL31MEE7uKUcPLT0nUhfmJJWm0KCbIyFMjW9Ykq3QwQRgC/WM1KwGo2trDgiAg0mzNfpqegA2EseFVLVL9e6fT9wIIJL8BemgDQXhwTMs//2Q==",
    img3 : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-D4OdVC_87ch-dCHkI5dYERx_89BPr7lEKw&usqp=CAU",
    price : 1000
  },
  //Catering
    "cs142": {
    name : "High Class Service",
    desc : "The service are carried out with greater professionalism having proper presentation and more hygiene",
    img1 : "https://happydays365.org/wp-content/uploads/2018/02/National-Waitstaff-Day.jpg",
    img2 : "https://joinposter.com/i/site/blog/10-common-mistakes-waiters-make-6a4a88eeb1852ea87d0744184570263a.jpg",
    price : 15000
  },
	"cs143": {
    name : "Average Services",
    desc : "Services are provided in low budget to make you and your guests at ease",
    img1 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/50082554_743357369379517_2572313899927863296_n.jpg?_nc_cat=111&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=t23aTgKCJFoAX-68PaI&_nc_ht=scontent.fmru7-1.fna&oh=a90efc2a328b67d597bc5549bfb9ac4c&oe=61D911F7",
    img2 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/33923868_580241572357765_162326420641546240_n.jpg?_nc_cat=108&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=QNOGqZljlLsAX_Em3-R&_nc_ht=scontent.fmru7-1.fna&oh=00_AT_kYROF3Py5SOt7UuoA6uucOiNpbsVpxDV2VpSqfh9JuA&oe=61D98FB9",
    price : 8000
  },
	//Deco
	"k144": {
    name : "Flowers",
    desc : "It' s your wedding, get beutiful floral decorations from our team. You can also send us your ideas",
    img1 : "https://www.edwigeboutique.com/images/si2-wedding.jpg",
    img2 : "https://www.edwigeboutique.com/images/si3-wedding.jpg",
    price : 60000
  },
	"k145": {
    name : "Cloth and Lightings",
    desc : "Make your wedding place looks more attractive with the amazing lights and shiny cloth",
    img1 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.18169-9/25446386_1397798636995602_5288463888088052764_n.jpg?_nc_cat=110&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=FTWh6XfIsAQAX_Rpscd&_nc_ht=scontent.fmru7-1.fna&oh=3527acd9873a212f5aed559889c10f67&oe=61D83767",
    img2 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.18169-9/18814018_1209502165825251_3182108957182134750_n.jpg?_nc_cat=106&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=ilbJt9o-4I4AX8Hz2L3&tn=3u-jR1bXj4OXCdCr&_nc_ht=scontent.fmru7-1.fna&oh=b0ff31269d0aa895259569d1c162ffec&oe=61DADBFF",
    price : 35000
  },
	"k146": {
    name : "Chair Decoration",
    desc : "The guests will be sitting at ease without worrying about their clothes getting dirty at all",
    img1 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/60795592_2072405569534902_1273031785457909760_n.jpg?_nc_cat=108&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=HuoK0bw7oacAX-3TBIu&tn=3u-jR1bXj4OXCdCr&_nc_ht=scontent.fmru7-1.fna&oh=00_AT-rDZjfOsYvACKbyEsOIOAGNLFQh85r8zG-EaaLa3HCnA&oe=61DA9384",
    img2 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/44461514_1760462577395871_7985490972416933888_n.jpg?_nc_cat=100&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=NHkOLEWAfAAAX8rVlQp&_nc_ht=scontent.fmru7-1.fna&oh=dea56ec51b8b3856e50c97c6f7aa4657&oe=61D9E886",
    
    price : 10000
  },
  //Sound
  "l147": {
    name : "DJ",
    desc : "Make your guests move all night within the groove",
    img1 : "https://campuslife.itcilo.org/leisure_time/music-with-gianfranco/Image_preview",
    img2 : "https://th.static-thomann.de/thumb//thumb640x/pics/cms/image/guide/en/dj_setups/djsetups_index.jpg",
    price : 25000
  },
  "l148": {
    name : "Karaoke",
    desc : "Listen to the soulful voices of our awesome singers. Guests are most welcomed to sing along",
    img1 : "https://media.glamour.com/photos/5695ff8293ef4b09520fa96f/master/pass/weddings-2015-06-woman-singing-karaoke-main.jpg",
    img2 : "./sing.jpg",
    price : 12000
  },
	"l149": {
    name : "Music Band",
    desc : "Listen to our famous band playing a variety of songs from old to new and from hollywood to bollywood songs",
    img1 : "https://www.thebalancecareers.com/thmb/xfSLg2_q66y64hprcpXZTclk8fc=/1600x900/smart/filters:no_upscale()/montreal-concerts-january-2018-james-barker-band-gustavo-caballero-getty-5a457f72eb4d520037bda7dc.jpg",
    img2 : "https://eventori.id/assets/images/foto_berita/img_1622103458.png",
    price : 50000
  },
  "x150": {
    name : "Civil Wedding",
    desc : "Sign your civil wedding at your own place",
    img1 : "https://upload.wikimedia.org/wikipedia/en/thumb/9/9a/CivilCeremonySignWitness.jpg/500px-CivilCeremonySignWitness.jpg",
    img2 : "https://cdn0.hitched.co.uk/articles/images/5/4/8/9/img_49845/kings-chapel-5363713.jpg",
    price : 30000
  },
  "y151": {
    name : "Catholic Wedding",
    desc : "For your wedding, the arrangement for the church and the pastor, both will be booked",
    img1 : "https://cloudfront.weddingmaps.com/wp-content/uploads/2021/09/Catholic-wedding.jpg",
    img2 : "https://www.exclusiveitalyweddings.com/DB_files/locations/3000_2000/catholic-wedding-in-amalfi-0401.jpg",
    price : 30000
  },
  "y152": {
    name : "Hindu Wedding",
    desc : "Its your opportunity for your wedding to happen with all the prayers required by our priest",
    img1 : "https://www.culturalindia.net/iliimages/Hindu%20Wedding.jpg",
    img2 : "https://www.pinkvilla.com/imageresize/katrina_vicky_haldi_photos.jpg?width=752&format=webp&t=pvorg",
    price : 30000
  },
  "y153": {
    name : "Muslim Wedding",
    desc : "Perform your Nikah by our great Imam",
    img1 : "https://i2.wp.com/www.weddingsutra.com/images/muslim-wedding-tradition-thumb.jpg?fit=900%2C900&ssl=1",
    img2 : "https://www.weddingdetails.com/wp-content/uploads/2019/03/muslimwedding.jpg",
    price : 30000
  },
 
  
	"z155": {
    name : "Bride Clothes",
    desc : "We are associated to many elegant boutik where you can buy your dream wedding dress to the prices",
    img1 : "https://i.pinimg.com/originals/6a/cf/07/6acf073bb3e800af125fbed24e951125.jpg",
    img2 : "https://www.brides.com/thmb/6jrzfkyiTwEhLJGotKAa4miq1CE=/2590x2590/smart/filters:no_upscale()/MJ112720tandon-Friday-1092-6ad8260df26d4f1c94728f86484f49f4.jpg",
    img3 : "https://i.pinimg.com/originals/54/9b/55/549b551f09fdada13a7286893aaad8fb.jpg",
    price : 50000
  },
  "z156": {
    name : "Bridegroom Clothes",
    desc : "We are associated with tailors and shops around the world where you will find clothes according to your size",
    img1 : "https://5.imimg.com/data5/PF/MT/MY-16403697/wedding-suits-500x500.jpg",
    img2 : "https://ae01.alicdn.com/kf/Hdeb46451036e4b5b881fa05004a57742B.jpg",
    img3 : "https://ds393qgzrxwzn.cloudfront.net/resize/c500x500/cat1/img/images/0/3xUracIICj.jpg",
    price : 50000
  },
  "w157": {
    name : "Photography",
    desc : "It is a way of feeling, of touching, of loving. What you have caught on film is captured forever your beautifull moment … It remembers little things, long after you have forgotten everything.",
    img1 : "https://static.independent.co.uk/2021/10/07/15/iStock-1151871081.jpg?width=1200",
    img2 : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSjmUKWsNe5pVbpsN7Zk6oCOwflgfVI59Iuw&usqp=CAU",
    price : 35000
  },
  "w158": {
    name : "Videography",
    desc : "Making memories is what we do. From telling stories through video to retelling the classics on film or shooting your engagement photos on your phones, we’re on your team",
    img1 : "https://www.uscreen.tv/wp-content/uploads/2018/11/Ultimate-video-production-equipment.jpg",
    img2 : "https://s0.hfdstatic.com/sites/the_hartford/pubimgs/1444706587896.jpg?v=2021-01-05_083934464",
    price : 35000
  },
  
};