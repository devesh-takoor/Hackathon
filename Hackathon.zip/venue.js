function addToCart(clicked_id)
  {
      alert(clicked_id);
      let Title;
      let Price; 
      if(clicked_id = 'WeddingHall'){
        Title = 'Wedding Hall';
        Price = 'Rs 75 000 per day';
      }
      else if(clicked_id = 'WeddingTent'){
        Title = 'Wedding Tent';
        Price = 'Rs 100 000';
      }
      else if(clicked_id = 'WeddingMarquee'){
        Title = 'Wedding Marquee';
        Price = 'Rs 300 000';
      }
      else{
        Title = 'Open Air Wedding';
        Price = 'Rs 150 000';
      }
    const fs = require('fs') 
    let data = "Learning how to write in a file."
    fs.writeFile('Output.txt', data, (err) => { 
        
        // In case of a error throw err. 
        if (err) alert(err); 
    }) 
  }
document.addEventListener("DOMContentLoaded", function(event) {


const cartButtons = document.querySelectorAll('.cart-button');

cartButtons.forEach(button => {

button.addEventListener('click',cartClick);

});

function cartClick(){
let button =this;
button.classList.add('clicked');
}

});