var food = {
  127: {
    name : "7 curry (with ti puri)",
    desc : "Delicious colourful curries with plenty of flavours and served with small puris",
    img1 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/51993453_2196501043748765_4302364243295993856_n.jpg?_nc_cat=107&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=ZTNf9SNXfxkAX8K_t4t&tn=3u-jR1bXj4OXCdCr&_nc_ht=scontent.fmru7-1.fna&oh=4397df9def2cf2fef324777ab951d9bd&oe=61D8D226",
    img2 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/51438020_2196501003748769_3308637011480412160_n.jpg?_nc_cat=102&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=uRa7ElgjZsUAX-zylZa&tn=3u-jR1bXj4OXCdCr&_nc_ht=scontent.fmru7-1.fna&oh=d6fcf87d4d2cd8ad90c36fd51a17646c&oe=61D86837",
    
    price : 75
  },
  128: {
    name : "7 curry (with rasson)",
    desc : "Extra hot and spicy curries accompanied by a spicy drink (rasson).",
    img1 : "https://i.ytimg.com/vi/sd_02ajSqT0/maxresdefault.jpg",
    img2 : "https://scontent.fmru7-1.fna.fbcdn.net/v/t1.6435-9/45425598_1511736805637617_1947713049636896768_n.jpg?_nc_cat=111&ccb=1-5&_nc_sid=e3f864&_nc_ohc=nqzVfw0J8Y8AX_0beOS&_nc_ht=scontent.fmru7-1.fna&oh=00_AT-fNJTFXT1lERanlhAlM3rlZBL1_8OHe6O9tkDNNCKKIQ&oe=61D83BCF",
    price : 80
  },
  129: {
    name : "Briyani",
    desc : "Quality Briyani obtained in veg, non-veg and halaal versions.",
    img1 : "https://media-cdn.tripadvisor.com/media/photo-s/1a/88/3c/1b/kannaas-banana-leaf-bamboo.jpg",
    img2 : "https://www.yummytummyaarthi.com/wp-content/uploads/2013/07/1-1.jpg",
    price : 100
  },
  1210: {
    name : "Dholl Puri Massala",
    desc : "Have some pairs of Dholl Puri with spicy massala curries.",
    img1 : "https://indianmasalamn.com/gallery/img21.jpg",
    img2 : "https://restaurants.mu/blog-admin/wp-content/uploads/2018/12/Sept-Cari.jpg",
    
    price : 110
  }
};

var drinks = {
  1211: {
    name : "Alcohlic Drinks",
    desc : "As alcohlic drinks we have imported brands and also our local beer",
    img1 : "https://images.theconversation.com/files/2982/original/3600947113_fe7208d8a8_b.jpg?ixlib=rb-1.1.0&q=45&auto=format&w=926&fit=clip",
    img2 : "https://i.ytimg.com/vi/HBEdwO-8Uz0/maxresdefault.jpg",
    
    price : 50
  },
  1212: {
    name : "Fizzy Drinks",
    desc : "We provide variety of fizzy drinks at lower costs.",
    img1 : "https://5.imimg.com/data5/QR/LR/ZW/IOS-44897149/product-jpeg-500x500.png",
    img2 : "https://static.toiimg.com/photo/59896244.cms?imgsize=444506",
    price : 10
  },
  1213: {
    name : "Coctails",
    desc : "Have a refreshing taste of our colourful and multi-flavour cocktails.",
    img1 : "https://www.orissapost.com/wp-content/uploads/2021/06/cocktails.jpg",
    img2 : "https://vedcdn.imgix.net/images/product/large/mixed-case-of-six-23124755.jpg?auto=compress,format",
    price : 15
  },
  1214: {
    name : "Mineral Water",
    desc : "No drinks can match or be better than the taste of water.(Price/Bottle)",
    img1 : "https://media-cldnry.s-nbcnews.com/image/upload/t_fit-1240w,f_auto,q_auto:best/newscms/2017_20/2003046/170515-nbc-water-illo-brecher-08-mainart.jpg",
    img2 : "https://cdn-a.william-reed.com/var/wrbm_gb_food_pharma/storage/images/5/2/7/4/2274725-1-eng-GB/Bottled-water-the-next-big-zero-cal-beverage_wrbm_large.jpg",
    
    price : 8
  }
};